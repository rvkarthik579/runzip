(() => {
  const canvas = document.getElementById('game');
  const ctx = canvas.getContext('2d');

  const WIDTH = canvas.width;
  const HEIGHT = canvas.height;
  const GROUND_Y = 230;
  const GRAVITY = 0.00255;
  const JUMP_VELOCITY = -0.7;
  const DUCK_HEIGHT = 30;
  const NORMAL_HEIGHT = 48;
  const DINO_WIDTH = 44;
  const DINO_X = 80;

  const BASE_SPEED = 0.36;
  const MAX_SPEED = 1.45;
  const SPEED_INCREASE = 0.0000038;
  const DINO_SPRITE_PATH = 'assets/bala.jpg';
  const JUMP_SOUND_PATH = 'assets/jump.wav';
  const SPRITE_SCALE_NORMAL = 1.35;
  const SPRITE_SCALE_DUCK = 1.45;
  const SPRITE_ROLL_MAX = 0.11;
  const JUMP_SPIN_DURATION = 430;

  canvas.style.filter = 'none';

  let lastTime = 0;
  let gameStarted = false;
  let gameOver = false;
  let gameTime = 0;
  let score = 0;
  let scoreHundredsPlayed = 0;
  let hiScore = Number(localStorage.getItem('dino-hi-score') || 0);

  const THEMES = {
    day: {
      background: '#ffffff',
      ink: '#535353',
      horizonDot: '#d5d5d5',
      horizonHill: '#cfcfcf',
      horizonCloud: '#bdbdbd',
    },
    night: {
      background: '#111111',
      ink: '#f1f1f1',
      horizonDot: '#4a4a4a',
      horizonHill: '#3f3f3f',
      horizonCloud: '#5a5a5a',
    },
  };

  let currentTheme = THEMES.day;

  const keys = {
    jumpPressed: false,
    duckHeld: false,
  };

  const dinoSprite = {
    image: new Image(),
    loaded: false,
    processedCanvas: null,
  };

  dinoSprite.image.onload = () => {
    const sourceWidth = dinoSprite.image.naturalWidth;
    const sourceHeight = dinoSprite.image.naturalHeight;

    const offscreen = document.createElement('canvas');
    offscreen.width = sourceWidth;
    offscreen.height = sourceHeight;
    const offCtx = offscreen.getContext('2d');

    offCtx.clearRect(0, 0, sourceWidth, sourceHeight);
    offCtx.drawImage(dinoSprite.image, 0, 0);

    const imgData = offCtx.getImageData(0, 0, sourceWidth, sourceHeight);
    const pixels = imgData.data;

    const samplePoints = [
      [0, 0],
      [sourceWidth - 1, 0],
      [0, sourceHeight - 1],
      [sourceWidth - 1, sourceHeight - 1],
      [Math.floor(sourceWidth / 2), 0],
      [Math.floor(sourceWidth / 2), sourceHeight - 1],
      [0, Math.floor(sourceHeight / 2)],
      [sourceWidth - 1, Math.floor(sourceHeight / 2)],
    ];

    let sampleCount = 0;
    let bgR = 255;
    let bgG = 255;
    let bgB = 255;
    let sumR = 0;
    let sumG = 0;
    let sumB = 0;

    for (const [sx, sy] of samplePoints) {
      const idx = (sy * sourceWidth + sx) * 4;
      const a = pixels[idx + 3];
      if (a < 8) continue;
      sumR += pixels[idx];
      sumG += pixels[idx + 1];
      sumB += pixels[idx + 2];
      sampleCount += 1;
    }

    let bgVariance = 0;

    if (sampleCount > 0) {
      bgR = sumR / sampleCount;
      bgG = sumG / sampleCount;
      bgB = sumB / sampleCount;

      for (const [sx, sy] of samplePoints) {
        const idx = (sy * sourceWidth + sx) * 4;
        const a = pixels[idx + 3];
        if (a < 8) continue;
        const dr = pixels[idx] - bgR;
        const dg = pixels[idx + 1] - bgG;
        const db = pixels[idx + 2] - bgB;
        bgVariance += dr * dr + dg * dg + db * db;
      }

      bgVariance /= sampleCount;
    }

    if (sampleCount > 0 && bgVariance < 680) {
      const pixelCount = sourceWidth * sourceHeight;
      const visited = new Uint8Array(pixelCount);
      const queue = [];
      let head = 0;

      function colorDistanceFor(x, y) {
        const idx = (y * sourceWidth + x) * 4;
        const dr = pixels[idx] - bgR;
        const dg = pixels[idx + 1] - bgG;
        const db = pixels[idx + 2] - bgB;
        return Math.sqrt(dr * dr + dg * dg + db * db);
      }

      function pushIfSeed(x, y) {
        const flatIndex = y * sourceWidth + x;
        if (visited[flatIndex]) return;
        const idx = flatIndex * 4;
        if (pixels[idx + 3] < 8) return;
        if (colorDistanceFor(x, y) > 56) return;
        visited[flatIndex] = 1;
        queue.push(flatIndex);
      }

      for (let x = 0; x < sourceWidth; x++) {
        pushIfSeed(x, 0);
        pushIfSeed(x, sourceHeight - 1);
      }

      for (let y = 0; y < sourceHeight; y++) {
        pushIfSeed(0, y);
        pushIfSeed(sourceWidth - 1, y);
      }

      while (head < queue.length) {
        const flatIndex = queue[head++];
        const x = flatIndex % sourceWidth;
        const y = Math.floor(flatIndex / sourceWidth);

        const neighbors = [
          [x - 1, y],
          [x + 1, y],
          [x, y - 1],
          [x, y + 1],
        ];

        for (const [nx, ny] of neighbors) {
          if (nx < 0 || nx >= sourceWidth || ny < 0 || ny >= sourceHeight) continue;
          const nFlat = ny * sourceWidth + nx;
          if (visited[nFlat]) continue;
          const idx = nFlat * 4;
          if (pixels[idx + 3] < 8) continue;
          if (colorDistanceFor(nx, ny) > 74) continue;
          visited[nFlat] = 1;
          queue.push(nFlat);
        }
      }

      for (let i = 0; i < pixelCount; i++) {
        if (visited[i]) {
          pixels[i * 4 + 3] = 0;
        }
      }
    }

    offCtx.putImageData(imgData, 0, 0);
    dinoSprite.processedCanvas = offscreen;
    dinoSprite.loaded = true;
  };

  dinoSprite.image.onerror = () => {
    dinoSprite.loaded = false;
    dinoSprite.processedCanvas = null;
  };

  dinoSprite.image.src = DINO_SPRITE_PATH;

  function getInkColor() {
    return currentTheme.ink;
  }

  const audio = {
    ctx: null,
  };

  const jumpSound = {
    audio: new Audio(JUMP_SOUND_PATH),
    loaded: false,
  };

  jumpSound.audio.preload = 'auto';
  jumpSound.audio.addEventListener('canplaythrough', () => {
    jumpSound.loaded = true;
  });
  jumpSound.audio.addEventListener('error', () => {
    jumpSound.loaded = false;
  });

  function ensureAudio() {
    if (!audio.ctx) {
      const AudioCtx = window.AudioContext || window.webkitAudioContext;
      if (!AudioCtx) return false;
      audio.ctx = new AudioCtx();
    }

    if (audio.ctx.state === 'suspended') {
      audio.ctx.resume();
    }

    return true;
  }

  function playTone({
    type = 'square',
    frequency = 440,
    duration = 0.08,
    volume = 0.03,
    frequencyEnd = null,
  }) {
    if (!ensureAudio()) return;

    const ctx = audio.ctx;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = type;
    osc.frequency.setValueAtTime(frequency, now);
    if (typeof frequencyEnd === 'number') {
      osc.frequency.exponentialRampToValueAtTime(Math.max(20, frequencyEnd), now + duration);
    }

    gain.gain.setValueAtTime(0.0001, now);
    gain.gain.exponentialRampToValueAtTime(volume, now + 0.01);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + duration);

    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(now);
    osc.stop(now + duration + 0.01);
  }

  function playJumpSound() {
    if (jumpSound.loaded) {
      jumpSound.audio.currentTime = 0;
      jumpSound.audio.play().catch(() => {
        playTone({ type: 'square', frequency: 340, frequencyEnd: 520, duration: 0.09, volume: 0.028 });
      });
      return;
    }

    playTone({ type: 'square', frequency: 340, frequencyEnd: 520, duration: 0.09, volume: 0.028 });
  }

  function playPointSound() {
    playTone({ type: 'square', frequency: 820, frequencyEnd: 1020, duration: 0.07, volume: 0.02 });
  }

  function playHitSound() {
    playTone({ type: 'sawtooth', frequency: 220, frequencyEnd: 120, duration: 0.12, volume: 0.035 });
    setTimeout(() => {
      playTone({ type: 'sawtooth', frequency: 150, frequencyEnd: 90, duration: 0.1, volume: 0.03 });
    }, 45);
  }

  const rng = {
    state: 1,
    reseed(seed) {
      this.state = seed >>> 0 || 1;
    },
    next() {
      let x = this.state;
      x ^= x << 13;
      x ^= x >>> 17;
      x ^= x << 5;
      this.state = x >>> 0;
      return this.state / 4294967296;
    },
    range(min, max) {
      return min + this.next() * (max - min);
    },
    int(min, maxInclusive) {
      return Math.floor(this.range(min, maxInclusive + 1));
    },
  };

  function newRunSeed() {
    const seed = (Date.now() ^ Math.floor(Math.random() * 0xffffffff)) >>> 0;
    rng.reseed(seed);
  }

  const dino = {
    x: DINO_X,
    y: GROUND_Y - NORMAL_HEIGHT,
    width: DINO_WIDTH,
    height: NORMAL_HEIGHT,
    velY: 0,
    grounded: true,
    ducking: false,
    legTimer: 0,
    legFrame: 0,
    rotation: 0,
    spinTime: 0,
    spinning: false,
    alive: true,
    reset() {
      this.y = GROUND_Y - NORMAL_HEIGHT;
      this.height = NORMAL_HEIGHT;
      this.velY = 0;
      this.grounded = true;
      this.ducking = false;
      this.legTimer = 0;
      this.legFrame = 0;
      this.rotation = 0;
      this.spinTime = 0;
      this.spinning = false;
      this.alive = true;
    },
    jump() {
      if (!this.grounded || gameOver) return;
      this.velY = JUMP_VELOCITY;
      this.grounded = false;
      this.spinTime = 0;
      this.spinning = true;
      playJumpSound();
    },
    setDuck(duck) {
      if (!this.grounded) return;
      this.ducking = duck;
      if (duck) {
        this.height = DUCK_HEIGHT;
        this.y = GROUND_Y - DUCK_HEIGHT;
      } else {
        this.height = NORMAL_HEIGHT;
        this.y = GROUND_Y - NORMAL_HEIGHT;
      }
    },
    update(delta) {
      if (!this.grounded) {
        if (keys.duckHeld) {
          this.velY += GRAVITY * delta * 0.9;
        }
        this.velY += GRAVITY * delta;
        this.y += this.velY * delta;

        if (this.spinning) {
          this.spinTime += delta;
          const progress = Math.min(1, this.spinTime / JUMP_SPIN_DURATION);
          this.rotation = progress * Math.PI * 2;
          if (progress >= 1) {
            this.spinning = false;
          }
        }

        if (this.y >= GROUND_Y - this.height) {
          this.y = GROUND_Y - this.height;
          this.velY = 0;
          this.grounded = true;
          this.rotation = 0;
          this.spinTime = 0;
          this.spinning = false;
        }
      }

      if (this.grounded && !gameOver) {
        this.legTimer += delta;
        if (this.legTimer > 90) {
          this.legTimer = 0;
          this.legFrame = (this.legFrame + 1) % 2;
        }

        if (!this.ducking) {
          this.rotation = Math.sin(gameTime * 0.03 + this.legFrame * Math.PI) * SPRITE_ROLL_MAX;
        } else {
          this.rotation = 0;
        }
      }
    },
    draw() {
      ctx.fillStyle = getInkColor();
      const x = Math.round(this.x);
      const y = Math.round(this.y);

      if (dinoSprite.loaded) {
        const sprite = dinoSprite.processedCanvas || dinoSprite.image;
        const rawWidth = sprite.width;
        const rawHeight = sprite.height;
        const widthTarget = this.ducking ? this.width + 12 : this.width;
        const scaleBoost = this.ducking ? SPRITE_SCALE_DUCK : SPRITE_SCALE_NORMAL;
        const scale = Math.min(widthTarget / rawWidth, this.height / rawHeight) * scaleBoost;
        const targetWidth = Math.round(rawWidth * scale);
        const targetHeight = Math.round(rawHeight * scale);
        const targetX = Math.round(x + (this.width - targetWidth) / 2);
        const targetY = Math.round(y + (this.height - targetHeight));

        const roll = this.rotation;

        const centerX = targetX + targetWidth / 2;
        const centerY = targetY + targetHeight / 2;
        ctx.save();
        ctx.translate(centerX, centerY);
        ctx.rotate(roll);
        ctx.drawImage(sprite, -targetWidth / 2, -targetHeight / 2, targetWidth, targetHeight);
        ctx.restore();
        return;
      }

      ctx.fillRect(x + 10, y + 4, 22, 16);
      ctx.fillRect(x + 26, y, 16, 12);
      ctx.fillRect(x, y + 16, 34, this.height - 16);
      ctx.fillRect(x + 34, y + 22, 8, 8);
      ctx.fillStyle = '#fff';
      ctx.fillRect(x + 34, y + 4, 4, 4);
      ctx.fillStyle = getInkColor();

      if (!this.grounded || this.ducking) {
        ctx.fillRect(x + 8, y + this.height - 10, 9, 10);
        ctx.fillRect(x + 24, y + this.height - 10, 9, 10);
      } else {
        if (this.legFrame === 0) {
          ctx.fillRect(x + 8, y + this.height - 12, 8, 12);
          ctx.fillRect(x + 24, y + this.height - 8, 8, 8);
        } else {
          ctx.fillRect(x + 8, y + this.height - 8, 8, 8);
          ctx.fillRect(x + 24, y + this.height - 12, 8, 12);
        }
      }
    },
    hitbox() {
      return {
        x: this.x + 4,
        y: this.y + 4,
        width: this.width - 8,
        height: this.height - 4,
      };
    },
  };

  const obstacles = [];
  let spawnTimer = 0;

  function createCactus(small = false) {
    const w = small ? 18 : 24;
    const h = small ? 35 : 50;
    return {
      type: 'cactus',
      x: WIDTH + 20,
      y: GROUND_Y - h,
      width: w,
      height: h,
      draw() {
        ctx.fillStyle = getInkColor();
        ctx.fillRect(this.x, this.y, this.width, this.height);
        ctx.fillRect(this.x - 6, this.y + 10, 6, 14);
        ctx.fillRect(this.x + this.width, this.y + 6, 6, 16);
      },
    };
  }

  function createBird() {
    const heights = [GROUND_Y - 90, GROUND_Y - 120, GROUND_Y - 150];
    const y = heights[rng.int(0, heights.length - 1)];
    return {
      type: 'bird',
      x: WIDTH + 20,
      y,
      width: 42,
      height: 30,
      flapTimer: 0,
      flap: 0,
      update(delta) {
        this.flapTimer += delta;
        if (this.flapTimer > 110) {
          this.flapTimer = 0;
          this.flap = 1 - this.flap;
        }
      },
      draw() {
        ctx.fillStyle = getInkColor();
        ctx.fillRect(this.x + 6, this.y + 8, 24, 10);
        if (this.flap === 0) {
          ctx.fillRect(this.x, this.y + 4, 10, 4);
          ctx.fillRect(this.x + 26, this.y + 4, 10, 4);
        } else {
          ctx.fillRect(this.x, this.y + 14, 10, 4);
          ctx.fillRect(this.x + 26, this.y + 14, 10, 4);
        }
        ctx.fillRect(this.x + 30, this.y + 10, 10, 4);
      },
    };
  }

  function overlaps(a, b) {
    return (
      a.x < b.x + b.width &&
      a.x + a.width > b.x &&
      a.y < b.y + b.height &&
      a.y + a.height > b.y
    );
  }

  const horizon = {
    dots: [],
    hills: [],
    clouds: [],
    reset() {
      this.dots = [];
      this.hills = [];
      this.clouds = [];

      const dotCount = 45;
      for (let i = 0; i < dotCount; i++) {
        this.dots.push({
          x: rng.range(0, WIDTH),
          y: rng.range(12, 120),
          size: rng.int(1, 2),
          speedFactor: rng.range(0.03, 0.08),
        });
      }

      const hillCount = 7;
      for (let i = 0; i < hillCount; i++) {
        this.hills.push({
          x: rng.range(0, WIDTH),
          width: rng.range(80, 200),
          height: rng.range(10, 28),
          speedFactor: rng.range(0.12, 0.2),
        });
      }

      const cloudCount = 4;
      for (let i = 0; i < cloudCount; i++) {
        this.clouds.push({
          x: rng.range(0, WIDTH),
          y: rng.range(30, 110),
          speedFactor: rng.range(0.05, 0.09),
          size: rng.range(0.85, 1.2),
        });
      }
    },
    update(delta, speed) {
      for (const dot of this.dots) {
        dot.x -= delta * speed * dot.speedFactor;
        if (dot.x < -4) {
          dot.x = WIDTH + rng.range(0, 80);
          dot.y = rng.range(12, 120);
        }
      }

      for (const hill of this.hills) {
        hill.x -= delta * speed * hill.speedFactor;
        if (hill.x + hill.width < 0) {
          hill.x = WIDTH + rng.range(30, 180);
          hill.width = rng.range(80, 200);
          hill.height = rng.range(10, 28);
        }
      }

      for (const cloud of this.clouds) {
        cloud.x -= delta * speed * cloud.speedFactor;
        if (cloud.x < -90) {
          cloud.x = WIDTH + rng.range(20, 180);
          cloud.y = rng.range(30, 110);
        }
      }
    },
    draw() {
      ctx.fillStyle = currentTheme.horizonDot;
      for (const dot of this.dots) {
        ctx.fillRect(dot.x, dot.y, dot.size, dot.size);
      }

      ctx.fillStyle = currentTheme.horizonHill;
      for (const hill of this.hills) {
        ctx.fillRect(hill.x, GROUND_Y - hill.height, hill.width, hill.height);
      }

      ctx.fillStyle = currentTheme.horizonCloud;
      for (const cloud of this.clouds) {
        const w = 46 * cloud.size;
        const h = 14 * cloud.size;
        ctx.fillRect(cloud.x, cloud.y + 6, w, h);
        ctx.fillRect(cloud.x + 8 * cloud.size, cloud.y, 14 * cloud.size, 8 * cloud.size);
        ctx.fillRect(cloud.x + 24 * cloud.size, cloud.y - 2 * cloud.size, 16 * cloud.size, 10 * cloud.size);
      }
    },
  };

  function resetRun() {
    gameOver = false;
    gameStarted = false;
    gameTime = 0;
    score = 0;
    scoreHundredsPlayed = 0;
    spawnTimer = 0;
    obstacles.length = 0;
    dino.reset();
    newRunSeed();
    horizon.reset();
  }

  function getSpeed() {
    return Math.min(MAX_SPEED, BASE_SPEED + gameTime * SPEED_INCREASE);
  }

  function spawnObstacle() {
    const speed = getSpeed();
    const canSpawnBird = score > 350;
    const birdChance = Math.min(0.3, 0.08 + score / 3000);
    const nextSpawnDelay = rng.range(1120, 1920) / speed;

    if (canSpawnBird && rng.next() < birdChance) {
      obstacles.push(createBird());
      spawnTimer = nextSpawnDelay;
      return;
    }

    const multiChance = speed > 0.58 ? 0.12 : 0.18;
    const cluster = rng.next() < multiChance ? 2 : 1;
    let cursor = WIDTH + 20;

    for (let i = 0; i < cluster; i++) {
      const small = rng.next() < 0.45;
      const cactus = createCactus(small);
      cactus.x = cursor;
      obstacles.push(cactus);
      cursor += cactus.width + rng.range(34, 52);
    }

    spawnTimer = nextSpawnDelay;
  }

  function updateObstacles(delta, speed) {
    spawnTimer -= delta;
    if (spawnTimer <= 0) {
      spawnObstacle();
    }

    for (let i = obstacles.length - 1; i >= 0; i--) {
      const obstacle = obstacles[i];
      obstacle.x -= delta * speed;
      if (obstacle.update) obstacle.update(delta);
      if (obstacle.x + obstacle.width < -20) {
        obstacles.splice(i, 1);
      }
    }
  }

  function drawGround(speed) {
    const offset = (gameTime * speed * 0.8) % 32;

    ctx.fillStyle = getInkColor();
    ctx.fillRect(0, GROUND_Y, WIDTH, 2);

    for (let x = -offset; x < WIDTH; x += 32) {
      ctx.fillRect(x, GROUND_Y + 6, 14, 2);
      ctx.fillRect(x + 20, GROUND_Y + 12, 8, 2);
    }
  }

  function drawScore() {
    ctx.fillStyle = getInkColor();
    ctx.font = '24px monospace';
    const padded = String(Math.floor(score / 10)).padStart(5, '0');
    const hi = String(Math.floor(hiScore / 10)).padStart(5, '0');
    const text = `HI ${hi}  ${padded}`;
    ctx.fillText(text, WIDTH - 250, 42);
  }

  function drawGameOver() {
    ctx.fillStyle = getInkColor();
    ctx.font = '34px Arial';
    ctx.fillText('GAME OVER', WIDTH / 2 - 115, 120);
    ctx.font = '22px Arial';
    ctx.fillText('Press Space to restart', WIDTH / 2 - 110, 155);

    const x = WIDTH / 2 - 20;
    const y = 175;
    ctx.fillRect(x, y, 40, 26);
    ctx.clearRect(x + 10, y + 8, 20, 10);
    ctx.fillRect(x + 14, y + 12, 12, 2);
  }

  function setThemeByScore() {
    const phase = Math.floor(score / 700) % 2;
    currentTheme = phase === 0 ? THEMES.day : THEMES.night;
    canvas.style.filter = 'none';
    canvas.style.background = currentTheme.background;
  }

  function update(delta) {
    if (!gameStarted || gameOver) return;

    gameTime += delta;
    score += delta * 0.1;

    const scoreNow = Math.floor(score / 10);
    const scoreHundreds = Math.floor(scoreNow / 100);
    if (scoreHundreds > scoreHundredsPlayed) {
      scoreHundredsPlayed = scoreHundreds;
      playPointSound();
    }

    const speed = getSpeed();

    dino.update(delta);
    horizon.update(delta, speed);
    updateObstacles(delta, speed);

    const box = dino.hitbox();
    for (const obstacle of obstacles) {
      if (overlaps(box, obstacle)) {
        gameOver = true;
        dino.alive = false;
        playHitSound();
        if (score > hiScore) {
          hiScore = Math.floor(score);
          localStorage.setItem('dino-hi-score', String(hiScore));
        }
        break;
      }
    }

    setThemeByScore();
  }

  function render() {
    ctx.clearRect(0, 0, WIDTH, HEIGHT);

    horizon.draw();
    drawGround(getSpeed());

    for (const obstacle of obstacles) obstacle.draw();

    dino.draw();
    drawScore();

    if (!gameStarted) {
      ctx.fillStyle = getInkColor();
      ctx.font = '30px Arial';
      ctx.fillText('Press Space to start', WIDTH / 2 - 130, 120);
    }

    if (gameOver) drawGameOver();
  }

  function frame(time) {
    const delta = Math.min(32, time - lastTime || 16);
    lastTime = time;

    update(delta);
    render();

    requestAnimationFrame(frame);
  }

  function startGameIfNeeded() {
    if (!gameStarted && !gameOver) {
      gameStarted = true;
      spawnTimer = 600;
    }
  }

  function onKeyDown(e) {
    ensureAudio();

    if (e.code === 'ArrowDown') {
      keys.duckHeld = true;
      dino.setDuck(true);
      return;
    }

    if (e.code === 'Space' || e.code === 'ArrowUp') {
      e.preventDefault();

      if (gameOver) {
        resetRun();
        return;
      }

      startGameIfNeeded();
      dino.jump();
      keys.jumpPressed = true;
    }
  }

  function onKeyUp(e) {
    if (e.code === 'ArrowDown') {
      keys.duckHeld = false;
      dino.setDuck(false);
    }

    if (e.code === 'Space' || e.code === 'ArrowUp') {
      keys.jumpPressed = false;
    }
  }

  document.addEventListener('keydown', onKeyDown);
  document.addEventListener('keyup', onKeyUp);

  resetRun();
  requestAnimationFrame(frame);
})();
